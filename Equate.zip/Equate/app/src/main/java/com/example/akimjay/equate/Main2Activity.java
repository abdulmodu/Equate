package com.example.akimjay.equate;

import android.support.annotation.RequiresPermission;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.akimjay.equate.R;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    Button but1, but2, but3, but4, but5, but6, but7, but8, but9, but0, btnplus, btnminus, btnmult, btndiv, btnequal, btndec,
    btnsci, btnclear, btnclearall, btnbrac;

    EditText editText;

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        but0 = (Button) findViewById(R.id.but0);
        but1 = (Button) findViewById(R.id.but1);
        but2 = (Button) findViewById(R.id.but2);
        but3 = (Button) findViewById(R.id.but3);
        but4 = (Button) findViewById(R.id.but4);
        but5 = (Button) findViewById(R.id.but5);
        but6 = (Button) findViewById(R.id.but6);
        but7 = (Button) findViewById(R.id.but7);
        but8 = (Button) findViewById(R.id.but8);
        but9 = (Button) findViewById(R.id.but9);
        btnplus = (Button) findViewById(R.id.btnplus);
        btnminus = (Button) findViewById(R.id.btnminus);
        btnmult = (Button) findViewById(R.id.btnmult);
        btndiv = (Button) findViewById(R.id.btndiv);
        btnequal = (Button) findViewById(R.id.btnequal);
        btndec = (Button) findViewById(R.id.btndec);
        btnsci = (Button) findViewById(R.id.btnsci);
        btnclear = (Button) findViewById(R.id.btnclear);
        btnclearall = (Button) findViewById(R.id.btnclearall);
        btnbrac = (Button) findViewById(R.id.btnbrac);

        editText = (EditText) findViewById(R.id.editText);

        textView = (TextView) findViewById(R.id.textView);

        try {
            but0.setOnClickListener(this);
            but1.setOnClickListener(this);
            but2.setOnClickListener(this);
            but3.setOnClickListener(this);
            but4.setOnClickListener(this);
            but5.setOnClickListener(this);
            but6.setOnClickListener(this);
            but7.setOnClickListener(this);
            but8.setOnClickListener(this);
            but9.setOnClickListener(this);
            btnplus.setOnClickListener(this);
            btnminus.setOnClickListener(this);
            btnmult.setOnClickListener(this);
            btndiv.setOnClickListener(this);
            btnequal.setOnClickListener(this);
            btndec.setOnClickListener(this);
            btnsci.setOnClickListener(this);
            btnclear.setOnClickListener(this);
            btnclearall.setOnClickListener(this);
            btnbrac.setOnClickListener(this);
        }
        catch (Exception e) {
        }
    }

    @Override
    public void onClick(View view) {

    }
}
